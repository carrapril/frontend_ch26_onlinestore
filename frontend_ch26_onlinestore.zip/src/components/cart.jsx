import "./cart.css";

const Cart = () => {
    return(
        <div className="home-page">
            <h1> CART ITEMS </h1>
            <h5>Ready to Checkout?</h5>
            
        </div>
    );

};

export default Cart;